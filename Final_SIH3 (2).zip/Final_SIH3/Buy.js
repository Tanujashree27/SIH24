function redirectToSeller() {
    window.location.href = "seller-page.html";
}
